/**
*	Kelas utama yang menjalankan Game.
*	@author Rakha Kanz Kautsar (1506688784)
*	@version 13.10.2015
*/
public class Main
{
	public static void main(String[] args){
		Game game = new Game();		
	}
}
