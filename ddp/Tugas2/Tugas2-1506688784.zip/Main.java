public class Main{
	public static void main(String[] args){
		NewGameFrame frame = new NewGameFrame();
		frame.setVisible(true);
	}
}
