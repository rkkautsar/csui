Cannon War
=====================================
<small>Version 0.2</small>

An attempt in creating a small game using Java. Similar to *gunbound*, but simpler in every aspects.

This is an assignment in Programming Basics at CSUI, 2015.

## Install & Run
```
javac *.java
java Main
```