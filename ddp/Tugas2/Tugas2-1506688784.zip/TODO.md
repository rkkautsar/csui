TODO
===============================

[ ] Add explosion (urgency: normal)
[ ] Add various wait (input, ball flying, etc) (urgency: low)
[ ] Or Add concurrent animation (more awesome)
[ ] Change angle input to mouse (urgency: low)

[x] Add health bar (urgency: high)
