public enum GameType {
	SOLO,
	PVP
}
